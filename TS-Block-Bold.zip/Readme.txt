
Introduction
~~~~~~~~~~~~
Thank you for downloading my "TS Block" Font for Windows, I hope you enjoy using it.
This is FREEWARE (NOT FOR SALE/NOT FOR COMMERIAL USE).
(This Read must be include with this font.) 

Requirements
~~~~~~~~~~~~
Windows 98,2000,Me�,XP�

Install
~~~~~~~
1. UnZip, install into C:\windows\fonts.

Uninstall
~~~~~~~~~
Delete the Startup\Settings\Control Panel\Fonts\(highlight font to be deleted)File\Delete.

Created By
~~~~~~~~~~
Date:9/25/2006
Filename: TS Block.zip 
Title: TS Block
Category:
Archive: Fonts

TS Block and Other Fonts are available.

Suggestions or comments sent to Steve Ferrera : supercarguy@hotmail.com

ENJOY!!!






RuFus


